export const Colors = {
  gray: "#E3E9EC",
  black: "#131212",
  darkGray: "#BFBFBF",
  white: "#fff",
  blue: "#2F9AAA",
  lightBlack: "#2B2B2B",
};
