import React from 'react'
import { View, Text } from 'react-native'
import LoginSvg from '../../assets/svg/LoginSvg'

const  Image = () => {
	return (
		<View>
			<LoginSvg />
		</View>
	)
}

export default Image
